
public enum ColorEnum {
	NEGRO, BLANCO, AZUL, VERDE, GRIS
}